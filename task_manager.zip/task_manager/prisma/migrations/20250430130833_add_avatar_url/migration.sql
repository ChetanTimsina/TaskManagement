-- AlterTable
ALTER TABLE "User" ADD COLUMN     "avatarUrl" TEXT;
