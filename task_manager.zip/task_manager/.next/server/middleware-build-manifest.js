globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_5210495e._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_24406989._.js",
      "static/chunks/[root-of-the-server]__890852fd._.js",
      "static/chunks/src_pages_index_5771e187._.js",
      "static/chunks/src_pages_index_f734908b._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_dist_f1d2d383._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__39d10e60._.js",
      "static/chunks/src_styles_globals_4738091e.css",
      "static/chunks/src_pages__app_5771e187._.js",
      "static/chunks/src_pages__app_30cf30f5._.js"
    ],
    "/dashboard": [
      "static/chunks/[root-of-the-server]__a4cfa04b._.js",
      "static/chunks/node_modules_next_0b1541d7._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/src_pages_dashboard_5771e187._.js",
      "static/chunks/src_pages_dashboard_49eb475a._.js"
    ],
    "/login": [
      "static/chunks/node_modules_next_557b0ea8._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_24406989._.js",
      "static/chunks/[root-of-the-server]__86576865._.js",
      "static/chunks/src_pages_login_5771e187._.js",
      "static/chunks/src_pages_login_53d27ef5._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];