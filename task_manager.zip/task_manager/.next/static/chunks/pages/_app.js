__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_f1d2d383._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__39d10e60._.js",
  "static/chunks/src_styles_globals_4738091e.css",
  "static/chunks/src_pages__app_5771e187._.js",
  "static/chunks/src_pages__app_30cf30f5._.js"
])
