__turbopack_load_page_chunks__("/register", [
  "static/chunks/node_modules_next_5210495e._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_24406989._.js",
  "static/chunks/[root-of-the-server]__43ee99d9._.js",
  "static/chunks/src_pages_register_5771e187._.js",
  "static/chunks/src_pages_register_60100146._.js"
])
