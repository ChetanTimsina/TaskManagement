__turbopack_load_page_chunks__("/api/tasks/delete", [
  "static/chunks/node_modules_next_a166bb8c._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__a4cfa04b._.js",
  "static/chunks/src_pages_dashboard_5771e187._.js",
  "static/chunks/src_pages_dashboard_71fa1085._.js"
])
