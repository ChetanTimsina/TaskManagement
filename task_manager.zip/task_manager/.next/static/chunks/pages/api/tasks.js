__turbopack_load_page_chunks__("/api/tasks", [
  "static/chunks/node_modules_next_b7851eaa._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__890852fd._.js",
  "static/chunks/src_pages_index_5771e187._.js",
  "static/chunks/src_pages_index_528c3d86._.js"
])
