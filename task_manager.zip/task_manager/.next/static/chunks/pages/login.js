__turbopack_load_page_chunks__("/login", [
  "static/chunks/node_modules_next_557b0ea8._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_24406989._.js",
  "static/chunks/[root-of-the-server]__86576865._.js",
  "static/chunks/src_pages_login_5771e187._.js",
  "static/chunks/src_pages_login_53d27ef5._.js"
])
